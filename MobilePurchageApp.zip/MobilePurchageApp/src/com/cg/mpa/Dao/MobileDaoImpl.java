package com.cg.mpa.Dao;

import java.sql.*;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.util.DBUtil;

public class MobileDaoImpl implements IMobileDao {

	
	Connection con;
	@Override
	public List<Mobile> getMobiles() throws MobileException {
		
		String sql="select * from mobiles";
		List<Mobile> mList = new ArrayList<>();
		try{
		
		con= DBUtil.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		while(rs.next())
		{
			Mobile m = new Mobile();
			m.setMobileId(rs.getInt(1));
			m.setName(rs.getString(2));
			m.setPrice(rs.getDouble(3));
			m.setQuantity(rs.getInt(4));
			mList.add(m);
		}
		}
		catch (SQLException e)
		{
			throw new MobileException("Problem in fetching details");
		}
		System.out.println(mList);
		return mList;
	}
	private int fetchPurchaseId() throws MobileException
	{
		int pid;
		String seq = "Select seq_purchaseid.NEXTVAL from dual";
		try
		{
			con= DBUtil.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(seq);
			rs.next();
			pid = rs.getInt(1);
		}
		catch (SQLException e)
		{
			throw new MobileException("Problem While Fetching Purchase Data");
		}
		return pid;
	}
	@Override
	public int insertPurchase(PurchaseDetails pdetails) throws MobileException {
		String sql = "INSERT INTO PurchaseDetails VALUES(?,?,?,?,?,?)";
		try{
		pdetails.setPurchaseId(fetchPurchaseId());
		con = DBUtil.getConnection();
	
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setInt(1,pdetails.getPurchaseId());
		pst.setString(2, pdetails.getCname());
		pst.setString(3, pdetails.getMailId());
		pst.setString(4,pdetails.getPhoneNo());
		pst.setDate(5,Date.valueOf(pdetails.getPurchasedate()));
		pst.setInt(6, pdetails.getMobileId());
		pst.executeUpdate();
		}
		catch (SQLException e)
		{
			throw new MobileException("Problem in fetching Mobile Date");
		}
		return pdetails.getPurchaseId();
		
	}

}
