package com.cg.mpa.dto;


import java.time.LocalDate;

public class PurchaseDetails {
	
		private	int purchaseId;
		private String cname;
		private String mailId;
		private	String phoneNo;
		private LocalDate Purchasedate;
		public int getPurchaseId() {
			return purchaseId;
		}
		public void setPurchaseId(int purchaseId) {
			this.purchaseId = purchaseId;
		}
		public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		public String getMailId() {
			return mailId;
		}
		public void setMailId(String mailId) {
			this.mailId = mailId;
		}
		public String getPhoneNo() {
			return phoneNo;
		}
		public void setPhoneNo(String phoneNo) {
			this.phoneNo = phoneNo;
		}
		public LocalDate getPurchasedate() {
			return purchasedate;
		}
		public void setPurchasedate( LocalDate purchasedate) {
			this.purchasedate = purchasedate;
		}
		public int getMobileId() {
			return mobileId;
		}
		public void setMobileId(int mobileId) {
			this.mobileId = mobileId;
		}
		private  LocalDate purchasedate;
		private int mobileId;
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + purchaseId;
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			PurchaseDetails other = (PurchaseDetails) obj;
			if (purchaseId != other.purchaseId)
				return false;
			return true;
		}
		@Override
		public String toString() {
			return "PurchaseDetails [purchaseId=" + purchaseId + ", cname="
					+ cname + ", mailId=" + mailId + ", phoneNo=" + phoneNo
					+ ", purchasedate=" + purchasedate + ", mobileId="
					+ mobileId + "]";
		}
		public PurchaseDetails(int purchaseId, String cname, String mailId,
				String phoneNo,  LocalDate purchasedate, int mobileId) {
			super();
			this.purchaseId = purchaseId;
			this.cname = cname;
			this.mailId = mailId;
			this.phoneNo = phoneNo;
			this.purchasedate = purchasedate;
			this.mobileId = mobileId;
		}
		public PurchaseDetails() {
			super();
		}
				
}
