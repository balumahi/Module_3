package com.cg.mpa.Controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.Service.IMobileService;
import com.cg.mpa.Service.MobileServiceImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;


@WebServlet({"/home","/Buy","/purchase"})
public class MobileController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MobileController() {
		super();

	}

	public void init(ServletConfig config) throws ServletException {

	}

	public void destroy() {

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		System.out.println(path);
		String url = "";
		IMobileService mser = new MobileServiceImpl();
		
		try {
			switch (path) {
			case "/home":
				List<Mobile> mlist = mser.getMobiles();
				request.setAttribute("mlist", mlist);
				url = "Home.jsp";
				System.out.println(mlist);
			break;
			case "/Buy":
				int mid=Integer.parseInt(request.getParameter("mid"));
				HttpSession sess = request.getSession(true);
				sess.setAttribute("mid",mid);
				url="Insert.jsp";
			break;
			case "/purchase":
				PurchaseDetails pdetails = new PurchaseDetails();
				pdetails.setCname(request.getParameter("cname"));
				pdetails.setMailId(request.getParameter("mailid"));
				pdetails.setPhoneNo(request.getParameter("phoneno"));
				
				String dateStr = request.getParameter("purchasedate");
				DateTimeFormatter fomat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				
				pdetails.setPurchasedate(LocalDate.parse(dateStr,fomat));
				sess = request.getSession(false);
				pdetails.setMobileId((Integer)sess.getAttribute("mid"));
				
				System.out.println(sess.getAttribute("mid"));
				int pid=mser.insertPurchase(pdetails);
				request.setAttribute("pdetails", pdetails);
				url = "Success.jsp";
				System.out.println(pdetails);
				break;
				

			}
		} catch (MobileException e) {
			request.setAttribute("error", e.getMessage());
			
			url = "Error.jsp";
		} catch (Exception e) {
			
			request.setAttribute("error", e.getMessage());
			url = "Error.jsp";
		}
		RequestDispatcher disp = request.getRequestDispatcher(url);
		disp.forward(request, response);
	}
}
