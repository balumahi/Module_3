package com.cg.mpa.Exception;

public class MobileException  extends RuntimeException{

	public MobileException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MobileException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public MobileException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public MobileException(String message) {
		super(message);
		
	}

	public MobileException(Throwable cause) {
		super(cause);
		
	}

}
