package com.cg.mpa.Service;

import java.util.List;

import com.cg.mpa.Dao.IMobileDao;
import com.cg.mpa.Dao.MobileDaoImpl;
import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;

public class MobileServiceImpl implements IMobileService{

	IMobileDao mdao = null;
	public MobileServiceImpl()
	{
		mdao = new MobileDaoImpl();
	}
	@Override
	public List<Mobile> getMobiles() throws MobileException {
		
		return mdao.getMobiles();
	}
	@Override
	public int insertPurchase(PurchaseDetails pdetails) throws MobileException {
		
		return mdao.insertPurchase(pdetails);
	}
}
