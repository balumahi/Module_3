package com.cg.mpa.Service;

import java.util.List;

import com.cg.mpa.Exception.MobileException;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;

public interface IMobileService {
	List<Mobile> getMobiles() throws MobileException;
	int insertPurchase(PurchaseDetails pdetails) throws MobileException;
}
