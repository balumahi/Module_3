package com.cg.ebc.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ebc.service.IBillService;

@WebServlet("/EBillController")
public class EBillController extends HttpServlet 
{
	IBillService billService ;
	ServletConfig conf ;
	private static final long serialVersionUID = 1L;

    public EBillController() 
    {
        super();
    }

	public void init(ServletConfig config) throws ServletException 
	{
		conf = config ;
	}

	public void destroy() 
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action = request.getParameter("action") ;
		if(action.equals("Login"))
		{
			String username = request.getParameter("txtUName") ;
			String password = request.getParameter("txtPass") ;
			
			if(username.equals("admin") && password.equals("admin"))
			{
				response.sendRedirect("DisplayResult.jsp");
			}
			else
			{
				PrintWriter out = response.getWriter() ;
				out.println("Enter correct Admin Credentials");
			}
		}
		
		if(action.equals("validateConsumer"))
		{
			String consumerNum = request.getParameter("txtConNum") ;
			String lmr = request.getParameter("txtLMR") ;
			String cmr = request.getParameter("txtCMR") ;
			
			request.setAttribute("conNum", consumerNum) ;
			request.setAttribute("lastMR", lmr) ;
			request.setAttribute("currentMR",cmr) ;
			
			RequestDispatcher rdValidate = request.getRequestDispatcher("/ValidateServlet") ;
			rdValidate.forward(request, response);
		}
		
	}

}
