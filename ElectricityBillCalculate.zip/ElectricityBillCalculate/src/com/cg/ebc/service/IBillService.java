package com.cg.ebc.service;

import com.cg.ebc.bean.BillDetails;
import com.cg.ebc.bean.Consumer;

public interface IBillService 
{
	public boolean isCustomerExist( int consumer_num ) ;
	public Consumer getConsumerDetails( int consumer_num ) ;
	public BillDetails addBillDetails( BillDetails billDetails ) ;
}
