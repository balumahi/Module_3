package com.cg.ebc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.ebc.bean.BillDetails;
import com.cg.ebc.bean.Consumer;
import com.cg.ebc.util.DBUtil;

public class BillDAOImpl implements IBillDAO 
{
	Connection con ;
	Statement stm ;
	PreparedStatement pstm ;
	ResultSet res ;
	
	@Override
	public boolean isCustomerExist(int consumer_num) 
	{
		boolean flag = false ;
		try
		{
			con = DBUtil.getConnection() ;
			pstm = con.prepareStatement("select count(*) from consumers where consumer_num=? ") ;
			pstm.setInt(1, consumer_num);
			res = pstm.executeQuery() ;
			res.next() ;
			int count = res.getInt(1) ;
			if( count==1 )
			{
				flag = true ;
			}
			else
			{
				flag = false ;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				res.close();
				pstm.close();
				con.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			
		}
		return flag;
	}

	@Override
	public Consumer getConsumerDetails(int consumer_num) 
	{
		Consumer consumer = null ;
		try
		{
			con = DBUtil.getConnection() ;
			pstm = con.prepareStatement("select * from consumers where consumer_num = ?") ;
			pstm.setInt(1, consumer_num);
			res = pstm.executeQuery() ;
			res.next() ;
			consumer = new Consumer() ;
			consumer.setConsumer_num(res.getInt("consumer_num"));
			consumer.setConsumer_name(res.getString("consumer_name"));
			consumer.setAddress(res.getString("address"));
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				res.close();
				pstm.close();
				con.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			
		}
		return consumer;
	}

	@Override
	public BillDetails addBillDetails(BillDetails billDetails) 
	{
		try
		{
			con = DBUtil.getConnection() ;
			stm = con.createStatement() ;
			res = stm.executeQuery("select seq_bill_num.nextval from dual ") ;
			if(	res.next() == false )
			{
				
			}
			int id = res.getInt(1) ;
			
			String query = "insert into BillDetails values(?,?,?,?,?,?)" ;
			
			pstm = con.prepareStatement(query) ;
			pstm.setInt(1, id);
			pstm.setInt(2, billDetails.getConsumernum());
			pstm.setInt(3, billDetails.getCurrentreading());
			pstm.setInt(4, billDetails.getUnitConsumed());
			pstm.setDouble(5, billDetails.getNetamount());
			pstm.setDate(6, billDetails.getBill_date());
			pstm.execute();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				pstm.close();
				con.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			
		}

		return billDetails;
	}

}
